//Name: Jujhar Grewal
//Due Date: 11/4/21
//Purpose: Creates a grid game

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;

import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.time.Duration;
import java.time.LocalDateTime;
import java.beans.*;
import java.text.*;

public class FlowFree extends JPanel implements ActionListener {

	// Global variables
	Panel p_card; // to hold all of the screens
	Panel card1, card2, card3, card4, card5; // the two screens
	Panel buttons, buttons1, buttons2;
	CardLayout cdLayout = new CardLayout();
	BoxLayout bLayout;
	JPanel statusPanel = new JPanel();
	JLabel statusLabel = new JLabel("Flow Free");
	JLabel moveLbl;
	int movesTotal = 0;
	JLabel instr;
	JProgressBar bar;
	JButton next, playAgain;
	String selectedCol;

	// grid
	int row = 5;
	int col = 5;
	int cur = 0;
	int level = 1; // a variable to track which level is displayed
	JButton a[] = new JButton[row * col];

	// background and button colours
	Color bckgrdCol = new Color(52, 170, 173);
	Color btnCol = new Color(49, 131, 133);
	// decides if dialog window should close
	Boolean exit = false;

	// will be used to display date/time at the beginning of game
	LocalDateTime start;
	// format DateTime as shown in quotes when you use dtf
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
	
	// Grid Arrays
	int b[][] = { { 3, 2, 0, 2, 6 }, { 0, 0, 0, 0, 0 }, { 4, 0, 6, 5, 0 }, { 0, 0, 0, 3, 0 }, { 0, 0, 0, 4, 5 } };

	int r[][] = { { 3, 2, 0, 2, 6 }, { 0, 0, 0, 0, 0 }, { 4, 0, 6, 5, 0 }, { 0, 0, 0, 3, 0 }, { 0, 0, 0, 4, 5 } };

	int w[][] = { { 3, 2, 10, 2, 6 }, { 11, 11, 14, 14, 14 }, { 4, 11, 6, 5, 13 }, { 12, 11, 11, 3, 13 },
			{ 12, 12, 12, 4, 5 } };

	// level 1
	int level1[][] = { { 3, 2, 0, 2, 6 }, { 0, 0, 0, 0, 0 }, { 4, 0, 6, 5, 0 }, { 0, 0, 0, 3, 0 }, { 0, 0, 0, 4, 5 } };

	int ans1[][] = { { 3, 2, 10, 2, 6 }, { 11, 11, 14, 14, 14 }, { 4, 11, 6, 5, 13 }, { 12, 11, 11, 3, 13 },
			{ 12, 12, 12, 4, 5 } };

	// level 2
	int level2[][] = { { 1, 0, 0, 0, 8 }, { 0, 0, 4, 0, 0 }, { 0, 0, 0, 8, 0 }, { 0, 7, 0, 4, 0 }, { 0, 1, 0, 0, 7 } };

	int ans2[][] = { { 1, 16, 16, 16, 8 }, { 9, 16, 4, 12, 12 }, { 9, 16, 16, 8, 12 }, { 9, 7, 15, 4, 12 },
			{ 9, 1, 15, 15, 7 } };

	// level 3
	int level3[][] = { { 5, 3, 0, 7, 0 }, { 0, 0, 0, 0, 0 }, { 2, 0, 5, 3, 0 }, { 0, 6, 0, 6, 0 }, { 2, 7, 0, 0, 0 } };

	int ans3[][] = { { 5, 3, 11, 7, 15 }, { 13, 13, 11, 11, 15 }, { 2, 13, 5, 3, 15 }, { 10, 6, 14, 6, 15 },
			{ 2, 7, 15, 15, 15 } };

	// Constructor 
	public FlowFree() {
		p_card = new Panel();
		// card Layout inside of border layout
		p_card.setLayout(cdLayout);
		screen1();
		screen2();
		screen3();
		screen4();
		screen5();

		setLayout(new BorderLayout());
		add("Center", p_card);

		// create the status bar panel and shove it down the bottom of the frame
		statusPanel.setBorder(new BevelBorder(BevelBorder.LOWERED));
		add(statusPanel, BorderLayout.SOUTH);
		statusPanel.setPreferredSize(new Dimension(getWidth(), 16));
		statusPanel.setLayout(new BoxLayout(statusPanel, BoxLayout.X_AXIS));
		start = LocalDateTime.now();
		statusLabel.setText(dtf.format(start));
		statusLabel.setHorizontalAlignment(SwingConstants.LEFT);
		statusPanel.add(statusLabel);
	}

	// create password GUI and show it
	public void password() {
		// Create and set up the window.
		JFrame frame = new JFrame("Password");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Create and set up the content pane.
		final Password newContentPane = new Password(frame);
		newContentPane.setOpaque(true); // content panes must be opaque
		frame.setContentPane(newContentPane);

		// Make sure the focus goes to the right component
		// whenever the frame is initially given the focus.
		frame.addWindowListener(new WindowAdapter() {
			public void windowActivated(WindowEvent e) {
				// if exit is true, exit the password dialog box
				if (exit) {
					exit = false;
					frame.dispose();
				}
				newContentPane.resetFocus();
			}
		});
		// Display the window.
		frame.pack();
		frame.setVisible(true);
	}

	// Copy one array depending on level into another (b, r, or w)
	public void copyOver(int m[][], int n[][]) { // copy every element of n into m
													// that changes the level
		for (int i = 0; i < row; i++)
			for (int j = 0; j < col; j++)
				m[i][j] = n[i][j];
	}

	// main screen
	public void screen1() { // screen 1 is set up.
		card1 = new Panel();
		card1.setBackground(bckgrdCol);
		JLabel title = new JLabel(createImageIcon("welcome.png"));

		// Entry into game
		JButton picButton = new JButton(createImageIcon("main.png"));
		picButton.setSize(10, 10);
		picButton.setActionCommand("pass");
		picButton.addActionListener(this);
		picButton.setBackground(Color.black);

		// Instructions
		instr = new JLabel("Click on the image to get started!");
		instr.setFont(new Font("Times New Roman", Font.BOLD, 35));
		instr.setForeground(Color.black);

		// Credits pop-up
		JButton creditsButton = new JButton("Credits");
		creditsButton.setActionCommand("credits");
		creditsButton.addActionListener(this);
		creditsButton.setBackground(btnCol);
		creditsButton.setForeground(Color.white);

		// quit game
		JButton quitButton = new JButton("Quit");
		quitButton.setActionCommand("quit");
		quitButton.addActionListener(this);
		quitButton.setBackground(btnCol);
		quitButton.setForeground(Color.white);

		// Setting to change dark and light mode
		JButton settingsButton = new JButton("Settings");
		settingsButton.setActionCommand("settings");
		settingsButton.addActionListener(this);
		settingsButton.setBackground(btnCol);
		settingsButton.setForeground(Color.white);

		// add to card1
		card1.add(title);
		card1.add(picButton);
		card1.add(instr);
		card1.add(creditsButton);
		card1.add(quitButton);
		card1.add(settingsButton);

		p_card.add("1", card1);
	}

	// instructions screen
	public void screen2() { // screen 2 is set up.
		// flow layout inside box layout inside card layout inside border layout
		card2 = new Panel();
		bLayout = new BoxLayout(card2, BoxLayout.Y_AXIS);
		card2.setLayout(bLayout);
		card2.setBackground(bckgrdCol);
		buttons2 = new Panel();
		buttons2.setBackground(bckgrdCol);

		statusLabel.setText("Game Instructions");
		// Instructions
		// Title
		JLabel title = new JLabel("INSTRUCTIONS");
		title.setFont(new Font("Times New Roman", Font.BOLD, 45));
		title.setForeground(Color.white);
		title.setAlignmentX(Component.CENTER_ALIGNMENT);

		JLabel text1 = new JLabel("Connect the images that are the same with each other.");
		text1.setAlignmentX(Component.CENTER_ALIGNMENT);

		JLabel text2 = new JLabel("Click on the image you want to start connecting.\n");
		text2.setAlignmentX(Component.CENTER_ALIGNMENT);

		JLabel text3 = new JLabel("You have to complete all 3 levels to win the game. Good luck!");
		text3.setAlignmentX(Component.CENTER_ALIGNMENT);

		JLabel text4 = new JLabel("The image above is an example of how this game works.");
		text4.setAlignmentX(Component.CENTER_ALIGNMENT);

		JLabel pic = new JLabel(createImageIcon("flowfree.png"));
		pic.setAlignmentX(Component.CENTER_ALIGNMENT);

		// buttons
		JButton menu = new JButton("Main Menu");
		menu.setBackground(btnCol);
		menu.setForeground(Color.white);
		menu.setActionCommand("s1");
		menu.addActionListener(this);

		next = new JButton("Next");
		next.setBackground(btnCol);
		next.setForeground(Color.white);
		next.setActionCommand("s3");
		next.addActionListener(this);

		// foreground colours
		title.setForeground(Color.white);
		text1.setForeground(Color.white);
		text2.setForeground(Color.white);
		text3.setForeground(Color.white);
		text4.setForeground(Color.white);
		
		// add buttons
		buttons2.add(menu);
		buttons2.add(next);

		// add items to cards, including buttons
		card2.add(title);
		card2.add(Box.createRigidArea(new Dimension(0, 20)));
		card2.add(pic);
		card2.add(Box.createRigidArea(new Dimension(0, 20)));
		card2.add(text4);
		card2.add(text1);
		card2.add(text2);
		card2.add(text3);
		card2.add(Box.createRigidArea(new Dimension(0, 20)));
		card2.add(buttons2);

		p_card.add("2", card2);
	}

	// Main game screen
	public void screen3() { // screen 3 is set up.
							// Game
		card3 = new Panel();
		card3.setBackground(bckgrdCol);
		// Title
		JLabel title = new JLabel("FLOW FREE");
		title.setFont(new Font("Times New Roman", Font.BOLD, 45));
		title.setForeground(Color.white);

		// Next button
		next = new JButton("Next");
		next.setBackground(btnCol);
		next.setForeground(Color.white);
		next.setActionCommand("s4");
		next.addActionListener(this);
		next.setEnabled(false);

		// Reset button
		JButton reset = new JButton("Reset");
		reset.setBackground(btnCol);
		reset.setForeground(Color.white);
		reset.setActionCommand("Reset");
		reset.addActionListener(this);

		// Quit button
		JButton quit = new JButton("Quit");
		quit.setBackground(btnCol);
		quit.setForeground(Color.white);
		quit.setActionCommand("quit");
		quit.addActionListener(this);

		// return to main menu
		JButton menu = new JButton("Main Menu");
		menu.setBackground(btnCol);
		menu.setForeground(Color.white);
		menu.setActionCommand("s1");
		menu.addActionListener(this);

		// moves counter
		moveLbl = new JLabel("Moves: " + movesTotal);
		moveLbl.setFont(new Font("Times New Roman", Font.BOLD, 15));
		moveLbl.setForeground(Color.white);
		moveLbl.setBackground(Color.white);

		// progress bar
		bar = new JProgressBar(0, 100);
		bar.setValue(0);
		bar.setStringPainted(true);

		// Set up grid
		Panel p = new Panel(new GridLayout(row, col));
		int moves = 0;
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				// add in when you have pictures
				a[moves] = new JButton(createImageIcon(b[i][j] + ".png"));
				// change to be your size
				a[moves].setPreferredSize(new Dimension(95, 95));
				a[moves].addActionListener(this);
				a[moves].setActionCommand("" + moves);
				p.add(a[moves]);
				moves++;
			}
		}

		// add to card3
		card3.add(title);
		card3.add(p);
		card3.add(moveLbl);
		card3.add(bar);
		card3.add(menu);
		card3.add(quit);
		card3.add(reset);
		card3.add(next);

		p_card.add("3", card3);
	}

	// Win screen
	public void screen4() { // screen 4 is set up.
		card4 = new Panel();
		bLayout = new BoxLayout(card4, BoxLayout.Y_AXIS);
		card4.setLayout(bLayout);
		card4.setBackground(bckgrdCol);
		buttons = new Panel();
		buttons.setBackground(bckgrdCol);

		// Title
		JLabel title = new JLabel("YOU WIN!");
		title.setFont(new Font("Times New Roman", Font.BOLD, 45));
		title.setForeground(Color.white);
		title.setAlignmentX(Component.CENTER_ALIGNMENT);

		// gif image
		JLabel win = new JLabel(createImageIcon("winscreen.gif"));
		win.setAlignmentX(Component.CENTER_ALIGNMENT);

		// Buttons
		JButton end = new JButton("Quit");
		end.setActionCommand("quit");
		end.setBackground(btnCol);
		end.setForeground(Color.white);
		end.addActionListener(this);

		JButton menu = new JButton("Main Menu");
		menu.setBackground(btnCol);
		menu.setForeground(Color.white);
		menu.setActionCommand("s1");
		menu.addActionListener(this);

		playAgain = new JButton("Play again");
		playAgain.setBackground(btnCol);
		playAgain.setForeground(Color.white);
		playAgain.setActionCommand("s3");
		playAgain.addActionListener(this);

		// add buttons to flow layout 
		buttons.add(menu);
		buttons.add(end);
		buttons.add(playAgain);

		// add flow layout and items to card4
		card4.add(Box.createRigidArea(new Dimension(0, 100)));
		card4.add(title);
		card4.add(win);
		card4.add(buttons);

		p_card.add("4", card4);
	}

	// Lose screen
	public void screen5() { // screen 5 is set up.
		card5 = new Panel();
		bLayout = new BoxLayout(card5, BoxLayout.Y_AXIS);
		card5.setLayout(bLayout);
		card5.setBackground(bckgrdCol);
		buttons1 = new Panel();
		buttons1.setBackground(bckgrdCol);

		// Title
		JLabel title = new JLabel("YOU LOSE!\n");
		title.setAlignmentX(Component.CENTER_ALIGNMENT);
		title.setFont(new Font("Times New Roman", Font.BOLD, 45));
		title.setForeground(Color.white);

		// Buttons
		JButton quit = new JButton("Quit");
		quit.setBackground(btnCol);
		quit.setForeground(Color.white);
		quit.setActionCommand("quit");
		quit.addActionListener(this);

		JButton menu = new JButton("Main Menu");
		menu.setBackground(btnCol);
		menu.setForeground(Color.white);
		menu.setActionCommand("s1");
		menu.addActionListener(this);

		JButton tryAgain = new JButton("Try again");
		tryAgain.setBackground(btnCol);
		tryAgain.setForeground(Color.white);
		tryAgain.setActionCommand("s3");
		tryAgain.addActionListener(this);

		// add buttons to buttons1 layout
		buttons1.add(menu);
		buttons1.add(quit);
		buttons1.add(tryAgain);

		// add items and rigid areas to card5
		card5.add(Box.createRigidArea(new Dimension(0, 220)));
		card5.add(title);
		card5.add(buttons1);

		p_card.add("5", card5);
	}

	// method to create Image Icons
	protected static ImageIcon createImageIcon(String path) { // change the red to your class name
		java.net.URL imgURL = FlowFree.class.getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}

	// main method in which frame is created
	public static void main(String[] args) {
		JFrame.setDefaultLookAndFeelDecorated(true);
		// Create and set up the window.
		JFrame frame = new JFrame("Flow Free");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Create and set up the content pane.
		JComponent newContentPane = new FlowFree();
		newContentPane.setOpaque(true);
		frame.setContentPane(newContentPane);
		frame.setSize(550, 650);
		frame.setVisible(true);
	}

	// method to redraw game grid
	public void redraw() {
		int move = 0;
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				a[move].setIcon(createImageIcon(b[i][j] + ".png"));
				move++;
			}
		}
	}

	// method to decide if user has won after each move, progress bar update, level up if won
	public void win() {
		// variables
		boolean win = true;
		int done = 0;
		int countProgress = 0;
		// for loops to go through grid
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				// if any piece doesn't match the answer, the user hasn't own
				if (b[i][j] != w[i][j])
					win = false;
				// if the piece does match, the progress towards correct answer being made
				else if (b[i][j] == w[i][j] && b[i][j] != 1 && b[i][j] != 2 && b[i][j] != 3 && b[i][j] != 4
						&& b[i][j] != 5 && b[i][j] != 6 && b[i][j] != 7 && b[i][j] != 8) {
					countProgress++;
				}

				// if the user has completely filled the grid but the answer is wrong, enable the next button to take them to the lose screen
				if (b[i][j] == 0 && b[i][j] != 1 && b[i][j] != 2 && b[i][j] != 3 && b[i][j] != 4 && b[i][j] != 5
						&& b[i][j] != 6 && b[i][j] != 7 && b[i][j] != 8) {
					done++;
				}
			}
		}

		// each piece is worth 7% progress
		bar.setValue(countProgress * 7);

		// if win
		if (win == true) {
			next.setActionCommand("s4");
			next.setEnabled(true);
			movesTotal = 0;
			bar.setValue(0);
			moveLbl.setText("Moves: " + movesTotal);
			bar.setValue(100);
			JOptionPane.showMessageDialog(card3, "You Win!!", getName(), JOptionPane.INFORMATION_MESSAGE);
			levelUp();
		// else if grid is fully filled
		} else if (done == 0) {
			next.setActionCommand("s5");
			next.setEnabled(true);
		}
	}

	// method to reset grid based on "r" array
	public void reset() {
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				b[i][j] = r[i][j];
			}
		}
		movesTotal = 0;
		moveLbl.setText("Moves: " + movesTotal);
		redraw();
	}

	// ,ethod to level up to go to the next level/win screen
	public void levelUp() {
		level++;
		if (level == 1) {
			copyOver(b, level1);
			copyOver(r, level1);
			copyOver(w, ans1);
			statusLabel.setText("Playing Level 1");
		} else if (level == 2) {
			copyOver(b, level2);
			copyOver(r, level2);
			copyOver(w, ans2);
			statusLabel.setText("Playing Level 2");
		} else if (level == 3) {
			copyOver(b, level3);
			copyOver(r, level3);
			copyOver(w, ans3);
			statusLabel.setText("Playing Level 3");
		} else { // show your final win screen.
			cdLayout.show(p_card, "4");
		}
		// call redraw to update the screen
		redraw();
		next.setEnabled(false);
	}

	// actionPerformed method to decide what a button click means 
	public void actionPerformed(ActionEvent e) { // moves between the screens
		// screen 1
		if (e.getActionCommand().equals("s1")) {
			cdLayout.show(p_card, "1");
			card1.setBackground(bckgrdCol);

			start = LocalDateTime.now();
			statusLabel.setText(dtf.format(start));
		} 
		// screen 2
		else if (e.getActionCommand().equals("s2")) {
			cdLayout.show(p_card, "2");
			card2.setBackground(bckgrdCol);
			buttons2.setBackground(bckgrdCol);
		} 
		// screen 3, and if level isn't 1 or 2, reset to 0
		else if (e.getActionCommand().equals("s3")) {
			movesTotal = 0;
			reset();
			bar.setValue(0);
			statusLabel.setText("Playing Level 1");

			if (level != 1 && level != 2) {
				level = 0;
				levelUp();
			}

			cdLayout.show(p_card, "3");
			card3.setBackground(bckgrdCol);
		} 
		// screen 4
		else if (e.getActionCommand().equals("s4")) {
			cdLayout.show(p_card, "4");
			card4.setBackground(bckgrdCol);
			buttons.setBackground(bckgrdCol);
		} 
		// screen 5
		else if (e.getActionCommand().equals("s5")) {
			cdLayout.show(p_card, "5");
			card5.setBackground(bckgrdCol);
			buttons1.setBackground(bckgrdCol);
		} 
		// reset button
		else if (e.getActionCommand().equals("Reset")) {
			reset();
		} 
		// password window
		else if (e.getActionCommand().equals("pass")) {
			password();
		} 
		// credits window
		else if (e.getActionCommand().equals("credits")) {
			UIManager UI = new UIManager();
			UI.put("OptionPane.background", bckgrdCol);
			UI.put("Panel.background", bckgrdCol);
			UI.put("OptionPane.messageForeground", Color.white);

			JOptionPane.showMessageDialog(null, "This game was brought to you by Jujhar Grewal", "Credits",
					JOptionPane.INFORMATION_MESSAGE);
		} 
		// quit button
		else if (e.getActionCommand().equals("quit")) {
			System.exit(0);
		} 
		// settings window with dropdown
		else if (e.getActionCommand().equals("settings")) {
			dropDown();
		}

		// all other clicks, which are in the grid game 
		else { // code to handle the game
			int n = Integer.parseInt(e.getActionCommand());
			int x = n / col;
			int y = n % col;
			if (b[x][y] == 1)
				cur = 9;
			else if (b[x][y] == 2)
				cur = 10;
			else if (b[x][y] == 3)
				cur = 11;
			else if (b[x][y] == 4)
				cur = 12;
			else if (b[x][y] == 5)
				cur = 13;
			else if (b[x][y] == 6)
				cur = 14;
			else if (b[x][y] == 7)
				cur = 15;
			else if (b[x][y] == 8)
				cur = 16;
			else {
				b[x][y] = cur;
				movesTotal++;
			}
			moveLbl.setText("Moves: " + movesTotal);
			redraw();
			win();
		}
	}

	// create progress bar GUI and show it
	public void dropDown() {
		// create a JFrame called Dropdown using dropdown constructor and set it to
		// visible
		DropDown frame = new DropDown();
		frame.setVisible(true);
	}

	// DropDown class
	public class DropDown extends JFrame {

		private JButton buttonSelect = new JButton("Select");

		// Dropdown constructor to create frame
		public DropDown() {
			super("Drop Down");

			setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));

			String[] cols = new String[] { "light mode", "dark mode" };

			// create a combo box with items specified in the Integer array:
			final JComboBox<String> list = new JComboBox<String>(cols);

			// customize some appearance:
			list.setForeground(Color.BLUE);
			list.setFont(new Font("Arial", Font.BOLD, 14));
			list.setMaximumRowCount(10);

			// add an event listener for the combo box
			list.addActionListener(new ActionListener() {

				// Method when action event occurs
				@Override
				public void actionPerformed(ActionEvent event) {
					JComboBox<String> combo = (JComboBox<String>) event.getSource();
					String selectedCol = (String) combo.getSelectedItem();

					DefaultComboBoxModel<String> model = (DefaultComboBoxModel<String>) combo.getModel();

					Integer selectedIndex = model.getIndexOf(selectedCol);
				}
			});

			// add event listener for the button Select
			buttonSelect.addActionListener(new ActionListener() {
				//
				@Override
				public void actionPerformed(ActionEvent event) {
					// Get the number chosen from the dropdown box
					selectedCol = (String) list.getSelectedItem();
					// if statement using ? operator to make background dark or light
					bckgrdCol = (selectedCol == "dark mode") ? Color.black : new Color(52, 170, 173);

					// switch statement to turn background dark or light
					switch (selectedCol) {
					case "dark mode":
						card1.setBackground(bckgrdCol);
						buttons2.setBackground(bckgrdCol);
						instr.setForeground(Color.white);
						break;
					default:
						card1.setBackground(bckgrdCol);
						buttons2.setBackground(bckgrdCol);
						instr.setForeground(Color.black);
					}

					// Once a selection is made, dispose of frame and go to main menu again
					dispose();
					System.out.println();
				}
			});

			// add components to this frame
			add(list);
			add(buttonSelect);

			pack();
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setLocationRelativeTo(null);
		}
	} // end DropDown

	// password class
	public class Password extends JPanel implements ActionListener {
		// "ok" button
		private String OK = "ok";
		// "help" button
		private String HELP = "help";

		private JFrame controllingFrame; // needed for dialogs
		private JPasswordField passwordField;

		public Password(JFrame f) {
			// Use the default FlowLayout.
			controllingFrame = f;

			// Create everything.
			passwordField = new JPasswordField(10);
			passwordField.setActionCommand(OK);
			passwordField.addActionListener(this);

			JLabel label = new JLabel("Enter the password: ");
			label.setLabelFor(passwordField);

			JComponent buttonPane = createButtonPanel();

			// Lay out everything.
			JPanel textPane = new JPanel(new FlowLayout(FlowLayout.TRAILING));
			textPane.add(label);
			textPane.add(passwordField);

			add(textPane);
			add(buttonPane);
		}

		// Method to create button panel
		protected JComponent createButtonPanel() {
			JPanel p = new JPanel(new GridLayout(0, 1));
			JButton okButton = new JButton("OK");
			JButton helpButton = new JButton("Help");

			okButton.setActionCommand(OK);
			helpButton.setActionCommand(HELP);
			okButton.addActionListener(this);
			helpButton.addActionListener(this);

			p.add(okButton);
			p.add(helpButton);

			return p;
		}

		// Method to perform actions based if there is an event
		public void actionPerformed(ActionEvent e) {
			String cmd = e.getActionCommand();

			if (OK.equals(cmd)) { // Process the password.
				char[] input = passwordField.getPassword();
				// if pass correct, start the game
				if (isPasswordCorrect(input)) {
					exit = true;

					// if password correct, go to screen 2
					cdLayout.show(p_card, "2");
					card2.setBackground(bckgrdCol);
					statusLabel.setText("Game Instructions");
				} else {
					JOptionPane.showMessageDialog(controllingFrame, "Invalid password. Try again.", "Error Message",
							JOptionPane.ERROR_MESSAGE);
				}

				// Zero out the possible password, for security.
				Arrays.fill(input, '0');

				passwordField.selectAll();
				resetFocus();
			} else { // The user has asked for help.
				JOptionPane.showMessageDialog(controllingFrame, "The password is \"Flow\"");
			}
		}

		/**
		 * Checks the passed-in array against the correct password. After this method
		 * returns, you should invoke eraseArray on the passed-in array.
		 */
		public boolean isPasswordCorrect(char[] input) {
			boolean isCorrect = true;
			char[] correctPassword = { 'F', 'l', 'o', 'w' };

			if (input.length != correctPassword.length) {
				isCorrect = false;
			} else {
				isCorrect = Arrays.equals(input, correctPassword);
			}

			// Zero out the password.
			Arrays.fill(correctPassword, '0');

			return isCorrect;
		}

		// Must be called from the event dispatch thread.
		protected void resetFocus() {
			passwordField.requestFocusInWindow();
		}
	} // end password
}
